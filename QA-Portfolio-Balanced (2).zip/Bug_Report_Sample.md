# Bug Report: Missing SNMP Auth Trap After Invalid Login

- **ID**: BUG-001
- **Feature**: SNMP
- **Build**: v7.0
- **Severity**: Major
- **Description**: Auth trap not received on trap receiver after failed SSH login with wrong credentials.
- **Steps**:
  1. Attempt SSH with invalid user/pass
  2. Observe trap receiver
- **Expected**: Auth trap (OID: `1.3.6.1.6.3.1.1.5.5`) to be received.
- **Actual**: No trap received.
- **Status**: Open