# Test Case: SNMP Trap Validation – Cold Start / Warm Start

## Objective:
Verify that SNMP traps are correctly generated and received after cold/warm start events in an HA setup.

### Steps:
1. Reboot the primary device in HA.
2. Observe trap receiver logs.
3. Validate presence of cold start/warm start trap.
4. Confirm source IP and OID correctness.

### Expected Result:
- Cold start trap received from newly rebooted device.
- Source IP is correct (mgmt/data interface).
- Trap OID is `1.3.6.1.6.3.1.1.5.1`

### Status: ✅ Passed