# Test Case: FlexConfig Deployment with Rollback

## Objective:
Ensure configuration is successfully deployed and rollback works in case of failure.

### Steps:
1. Deploy valid FlexConfig.
2. Check CLI for correct configuration.
3. Deploy invalid FlexConfig.
4. Validate automatic rollback.
5. Confirm system stability.

### Expected:
- Valid config: Successfully applied.
- Invalid config: Rolled back and alert raised.

### Status: ✅ Passed