# Test Case: User Login Validation

## Objective:
Verify that the user is able to log in successfully with valid credentials and is blocked with invalid ones.

### Steps:
1. Navigate to the login page.
2. Enter valid username and password.
3. Click "Login".
4. Verify redirection to the dashboard.
5. Attempt login with incorrect credentials.
6. Verify error message is displayed and login is blocked.

### Expected Results:
- Valid login redirects to the dashboard.
- Invalid login shows proper error message.
- No system crash or exposure of sensitive data.

### Status: ✅ Passed