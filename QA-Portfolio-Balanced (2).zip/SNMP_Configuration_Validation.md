> 🛡️ *Note: This test case reflects industry-standard SNMPv3 validation steps only. It does not include any proprietary information or internal tools from Cisco or any former employer.*

# Test Case: SNMP Configuration and Validation

## Objective:
Validate the SNMPv3 configuration, user setup, and correct trap forwarding behavior in a secure HA environment.

### Configuration Steps:
1. Configure SNMPv3 user with authPriv (SHA/AES).
2. Assign access group and enable SNMP host (trap receiver).
3. Set correct interface (mgmt/data) for trap source.
4. Enable specific trap types (e.g., cold start, warm start, link up/down, auth trap).

### Validation Steps:
1. SSH into device and apply SNMP config.
2. Use `show snmp` and `show running-config snmp` to verify.
3. Restart device to test cold start trap.
4. Failover active device and observe warm start or link down trap.
5. Attempt invalid SSH login to trigger auth trap.
6. Monitor traps on external receiver tool.

### Expected Results:
- SNMPv3 user is created and security level is correctly applied.
- Traps are received with correct OIDs and source IPs.
- Auth traps received on invalid login.
- No duplicate or missing traps during HA switch.

### Status: ✅ Passed